<?php
/* Copyright (C) NAVER <http://www.navercorp.com> */

/**
 * @class WidgetHandler
 * @author NAVER (developers@xpressengine.com)
 * @brief Handler class for widget execution
 * @remark it is empty for now, it would be removed in the future
 */
class WidgetHandler
{

	var $widget_path = '';

}
/* End of file WidgetHandler.class.php */
/* Location: ./classes/widget/WidgetHandler.class.php */
